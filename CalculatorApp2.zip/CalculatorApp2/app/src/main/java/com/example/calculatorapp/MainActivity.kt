package com.example.calculatorapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var resultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultText = findViewById(R.id.resultText)
    }

    fun appendText(view: View) {
        val button = view as Button
        val value = button.text.toString()
        if (resultText.text == "0" || resultText.text == "Error") {
            resultText.text = value
        } else {
            resultText.append(value)
        }
    }

    fun clearText(view: View) {
        resultText.text = "0"
    }

    fun deleteLast(view: View) {
        val current = resultText.text.toString()
        resultText.text = if (current.length > 1) current.dropLast(1) else "0"
    }

    fun calculateResult(view: View) {
        try {
            val expression = ExpressionBuilder(resultText.text.toString()).build()
            val result = expression.evaluate()
            resultText.text = result.toString()
        } catch (e: Exception) {
            resultText.text = "Error"
        }
    }
}